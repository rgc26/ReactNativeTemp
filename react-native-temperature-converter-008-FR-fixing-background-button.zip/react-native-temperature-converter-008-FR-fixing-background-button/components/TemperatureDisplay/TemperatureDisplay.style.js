import { StyleSheet } from "react-native";

const s = StyleSheet.create({
  text: {
    fontSize: 80,
    color: "white",
  },
});

export { s };
