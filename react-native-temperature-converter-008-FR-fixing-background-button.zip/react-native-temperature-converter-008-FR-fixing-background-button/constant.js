export const DEFAULT_TEMPERATURE = "0";
export const UNITS = {
  celcius: "°C",
  faranheit: "°F",
};
export const DEFAULT_UNIT = UNITS.celcius;
