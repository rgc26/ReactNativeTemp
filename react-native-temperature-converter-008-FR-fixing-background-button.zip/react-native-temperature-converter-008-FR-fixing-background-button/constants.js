export const UNITS = {
  celcius: "°C",
  faranheit: "°F",
};
